"""
Match service — SOLO LEE CACHE. Nunca scrapea en request.
Orden de lectura: cache fresco → last_valid → [] (con log de causa).
"""
import logging
from app.models.match import Match
from app.cache import cache

logger = logging.getLogger(__name__)

STATUS_ORDER = {"live": 0, "upcoming": 1, "finished": 2}


def _sort(matches: list) -> list:
    return sorted(
        matches,
        key=lambda m: (STATUS_ORDER.get(m.status, 9), m.start_time or "")
    )


async def _read_cache(key: str) -> list[Match]:
    """
    Lee cache → last_valid → [].
    Loggea la fuente para facilitar diagnóstico en Railway.
    NUNCA scrapea, NUNCA devuelve mocks.
    """
    data = await cache.get(key)
    if data is not None:
        return data

    data = await cache.get_last_valid(key)
    if data is not None:
        logger.info(f"[match_service] {key}: cache expirado, usando last_valid ({len(data)} items)")
        return data

    logger.info(f"[match_service] {key}: sin datos (cache vacío y sin last_valid — ¿scheduler corrió?)")
    return []


# ── Endpoints públicos ──────────────────────────────────────────────────────

async def get_hoy() -> dict:
    """
    Agenda completa del día — lee hoy:all del agregador.
    Si hoy:all está vacío, intenta leer cada MVP sport individualmente
    como fallback (útil en primer boot antes de que corra job_hoy_agregador).
    """
    from app.config import settings

    matches: list[Match] = await _read_cache("hoy:all")

    if not matches:
        logger.info("[match_service] hoy:all vacío — intentando fallback por sport")
        for sport in settings.mvp_sports:
            sport_data = await _read_cache(f"today:{sport}")
            matches.extend(sport_data)

    live      = [m for m in matches if m.status == "live"]
    upcoming  = [m for m in matches if m.status == "upcoming"]
    finished  = [m for m in matches if m.status == "finished"]

    return {
        "en_vivo":     _sort(live),
        "proximos":    _sort(upcoming),
        "finalizados": _sort(finished),
        "total":       len(matches),
    }


async def get_futbol_hoy() -> list[Match]:
    return _sort(await _read_cache("today:futbol"))


async def get_futbol_live() -> list[Match]:
    data = await _read_cache("live:futbol")
    return [m for m in data if m.status == "live"]


async def get_tenis_hoy() -> list[Match]:
    return _sort(await _read_cache("today:tenis"))


async def get_basquet_hoy() -> list[Match]:
    return _sort(await _read_cache("today:basquet"))


async def get_rugby_hoy() -> list[Match]:
    return _sort(await _read_cache("today:rugby"))


async def get_hockey_hoy() -> list[Match]:
    return _sort(await _read_cache("today:hockey"))


async def get_sport_hoy(sport: str) -> list[Match]:
    return _sort(await _read_cache(f"today:{sport}"))


# ── Compat con rutas /api/matches/* ────────────────────────────────────────

async def get_live_matches(sport: str | None = None) -> list[Match]:
    if sport:
        data = await _read_cache(f"live:{sport}")
        return [m for m in data if m.status == "live"]
    # Sin filtro: live de fútbol (más confiable) + live del agregador
    live_futbol = await _read_cache("live:futbol")
    hoy_all = await _read_cache("hoy:all")
    live_all = [m for m in hoy_all if m.status == "live"]
    # Merge sin duplicados
    seen = {m.id for m in live_futbol}
    merged = list(live_futbol)
    for m in live_all:
        if m.id not in seen:
            merged.append(m)
    return _sort(merged)


async def get_today_matches(sport: str | None = None) -> list[Match]:
    if sport:
        return await get_sport_hoy(sport)
    hoy = await get_hoy()
    return _sort(hoy["en_vivo"] + hoy["proximos"] + hoy["finalizados"])


async def get_results_matches(sport: str | None = None) -> list[Match]:
    matches = await get_today_matches(sport)
    return [m for m in matches if m.status == "finished"]


async def get_argentina_matches() -> list[Match]:
    hoy = await get_hoy()
    all_m = hoy["en_vivo"] + hoy["proximos"] + hoy["finalizados"]
    arg = [m for m in all_m if getattr(m, "argentina_relevance", "none") != "none"]
    if not arg:
        logger.info("[match_service] argentina_matches: 0 resultados — filtro editorial vacío")
    return _sort(arg)


async def get_club_matches(club_id: str) -> list[Match]:
    all_m = await get_today_matches()
    q = club_id.lower().replace("-", " ")
    return [
        m for m in all_m
        if q in (m.home_team or "").lower()
        or q in (m.away_team or "").lower()
        or q == (m.argentina_team or "").lower()
    ]
