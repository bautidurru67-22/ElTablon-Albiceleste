"""
Bridge entre FastAPI y el paquete scraping.
Resuelve imports en Railway (PYTHONPATH=/app/backend:/app) y local.
"""
import sys
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def _ensure_scraping_importable() -> bool:
    # Intento 1: import directo (funciona si PYTHONPATH está bien)
    try:
        import scraping           # noqa
        import scraping.registry  # noqa
        logger.info("[bridge] scraping importado OK (PYTHONPATH estándar)")
        return True
    except ImportError:
        pass

    # Intento 2: path fix — busca el paquete scraping relativo a este archivo
    bridge = Path(__file__).resolve()
    candidates = [
        bridge.parents[2],      # /app/backend/../  →  /app
        bridge.parents[3],      # un nivel más arriba por si acaso
        Path("/app"),           # Railway hardcoded
        Path("/app/backend").parent,  # /app
    ]

    tried: list[str] = []
    for candidate in candidates:
        s = str(candidate)
        if not candidate.exists():
            continue
        if s in tried:
            continue
        tried.append(s)
        if s not in sys.path:
            sys.path.insert(0, s)
            logger.info(f"[bridge] sys.path += {s}")

    try:
        import scraping           # noqa
        import scraping.registry  # noqa
        logger.info(f"[bridge] scraping importado OK (path fix, tried={tried})")
        return True
    except ImportError as e:
        logger.error(
            f"[bridge] FALLO import scraping: {e} | "
            f"tried paths={tried} | "
            f"sys.path={sys.path}"
        )
        return False


_SCRAPING_OK = _ensure_scraping_importable()


# Import diferido para no crashear si Match no existe aún
def _get_match_model():
    from app.models.match import Match
    return Match


def _to_match(nm):
    """Convierte NormalizedMatch → Match (modelo Pydantic del backend)."""
    Match = _get_match_model()
    return Match(
        id=nm.id,
        sport=nm.sport,
        competition=nm.competition,
        home_team=nm.home_team,
        away_team=nm.away_team,
        home_score=nm.home_score,
        away_score=nm.away_score,
        status=nm.status,
        minute=nm.minute,
        datetime=getattr(nm, "datetime_utc", None) and str(getattr(nm, "datetime_utc")),
        start_time=getattr(nm, "start_time_arg", None),
        argentina_relevance=nm.argentina_relevance,
        argentina_team=nm.argentina_team,
        broadcast=getattr(nm, "broadcast", None),
    )
