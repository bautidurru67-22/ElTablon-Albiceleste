"""
Health + debug endpoints.
/api/health              — siempre vivo (Railway healthcheck)
/api/health/full         — estado del sistema + cache
/api/debug/scraping      — test en vivo de un deporte
/api/debug/all           — test rápido de todos los MVP sports
"""
import time
import logging
from fastapi import APIRouter
from app.cache import cache

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/health")
async def health():
    return {"status": "ok", "service": "tablon-albiceleste-api"}


@router.get("/health/full")
async def health_full():
    from app.config import settings
    from app.scraping_bridge import _SCRAPING_OK

    cache_stats = await cache.stats()
    keys = cache_stats.get("keys", [])
    lv_keys = cache_stats.get("last_valid_keys", [])

    # Estado por cada MVP sport
    sport_cache: dict[str, dict] = {}
    for sport in settings.mvp_sports:
        key = f"today:{sport}"
        meta = await cache.get_meta(key)
        sport_cache[sport] = meta

    return {
        "status": "ok",
        "timestamp": time.time(),
        "scraping_ok": _SCRAPING_OK,
        "mvp_sports": settings.mvp_sports,
        "cache": {
            "backend": cache_stats.get("backend"),
            "active_keys": len(keys),
            "keys": keys,
            "last_valid_keys": lv_keys,
        },
        "sport_cache": sport_cache,
    }


@router.get("/debug/scraping")
async def debug_scraping(sport: str = "futbol"):
    """
    Corre scraping EN VIVO para un deporte.
    ?sport=futbol|tenis|basquet|rugby|hockey|voley|handball|futsal|golf|boxeo|motorsport|motogp
    """
    t0 = time.monotonic()
    result: dict = {
        "sport": sport,
        "scraping_ok": False,
        "adapter_found": False,
        "total_before_filter": 0,
        "count_argentina": 0,
        "sample": [],
        "errors": [],
        "duration_ms": 0,
    }

    try:
        from app.scraping_bridge import _SCRAPING_OK
        result["scraping_ok"] = _SCRAPING_OK

        if not _SCRAPING_OK:
            result["errors"].append("scraping package no importable — revisar PYTHONPATH en Railway")
            result["duration_ms"] = round((time.monotonic() - t0) * 1000)
            return result

        from scraping.registry import ADAPTER_REGISTRY
        result["available_adapters"] = list(ADAPTER_REGISTRY.keys())

        if sport not in ADAPTER_REGISTRY:
            result["errors"].append(
                f"'{sport}' no está en ADAPTER_REGISTRY. "
                f"Disponibles: {list(ADAPTER_REGISTRY.keys())}"
            )
            result["duration_ms"] = round((time.monotonic() - t0) * 1000)
            return result

        result["adapter_found"] = True

        from scraping.orchestrator.coordinator import ScrapingCoordinator
        coord = ScrapingCoordinator(
            {sport: ADAPTER_REGISTRY[sport]},
            timeout_per_adapter=25,
        )
        normalized = await coord.run_all_flat()
        arg = coord.get_argentina_matches(normalized)

        result["total_before_filter"] = len(normalized)
        result["count_argentina"] = len(arg)
        result["sample"] = [
            {
                "home": m.home_team,
                "away": m.away_team,
                "score": (
                    f"{m.home_score}-{m.away_score}"
                    if m.home_score is not None else None
                ),
                "status": m.status,
                "minute": m.minute,
                "competition": m.competition,
                "source": m.source,
                "relevance": m.argentina_relevance,
                "start_time": m.start_time_arg,
            }
            for m in arg[:10]
        ]

    except Exception as e:
        logger.error(f"[debug/scraping] {sport}: {e}", exc_info=True)
        result["errors"].append(str(e))

    result["duration_ms"] = round((time.monotonic() - t0) * 1000)
    return result


@router.get("/debug/all")
async def debug_all_sports():
    """
    Test de todos los MVP sports en paralelo.
    Muestra count total, count argentina, sample y errores por deporte.
    """
    from app.config import settings
    import asyncio

    t0 = time.monotonic()
    summary: dict = {}

    try:
        from app.scraping_bridge import _SCRAPING_OK
        if not _SCRAPING_OK:
            return {
                "scraping_ok": False,
                "error": "scraping package no importable",
                "duration_ms": round((time.monotonic() - t0) * 1000),
            }

        from scraping.registry import ADAPTER_REGISTRY
        available = list(ADAPTER_REGISTRY.keys())

        async def _test_sport(sport: str) -> tuple[str, dict]:
            sport_t0 = time.monotonic()
            info: dict = {
                "adapter_found": sport in ADAPTER_REGISTRY,
                "total": 0,
                "argentina": 0,
                "sample": [],
                "error": None,
                "duration_ms": 0,
            }
            if not info["adapter_found"]:
                info["error"] = "no adapter en registry"
                info["duration_ms"] = round((time.monotonic() - sport_t0) * 1000)
                return sport, info
            try:
                from scraping.orchestrator.coordinator import ScrapingCoordinator
                coord = ScrapingCoordinator(
                    {sport: ADAPTER_REGISTRY[sport]},
                    timeout_per_adapter=20,
                )
                normalized = await coord.run_all_flat()
                arg = coord.get_argentina_matches(normalized)
                info["total"] = len(normalized)
                info["argentina"] = len(arg)
                info["sample"] = [
                    {"home": m.home_team, "away": m.away_team, "source": m.source}
                    for m in arg[:3]
                ]
            except Exception as e:
                info["error"] = str(e)
                logger.error(f"[debug/all] {sport}: {e}", exc_info=True)

            info["duration_ms"] = round((time.monotonic() - sport_t0) * 1000)
            return sport, info

        tasks = [_test_sport(s) for s in settings.mvp_sports]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for item in results:
            if isinstance(item, Exception):
                logger.error(f"[debug/all] tarea fallida: {item}")
                continue
            sport, info = item
            summary[sport] = info

    except Exception as e:
        logger.error(f"[debug/all] {e}", exc_info=True)
        summary["_error"] = str(e)

    return {
        "scraping_ok": True,
        "duration_ms": round((time.monotonic() - t0) * 1000),
        "mvp_sports": settings.mvp_sports,
        "sports": summary,
    }
