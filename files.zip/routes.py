from fastapi import APIRouter
from app.api import matches, health
from app.api.hoy import router as hoy_router

router = APIRouter()

# Siempre vivos
router.include_router(health.router, tags=["health"])

# Hoy — agenda del día
router.include_router(hoy_router, prefix="/hoy", tags=["hoy"])

# Matches — compat con frontend actual
router.include_router(matches.router, prefix="/matches", tags=["matches"])

# Opcionales — no rompen startup si no existen
try:
    from app.api import auth
    router.include_router(auth.router, prefix="/auth", tags=["auth"])
except Exception:
    pass

try:
    from app.api import favorites
    router.include_router(favorites.router, prefix="/favorites", tags=["favorites"])
except Exception:
    pass

try:
    from app.api import sports
    router.include_router(sports.router, prefix="/sports", tags=["sports"])
except Exception:
    pass

try:
    from app.api import players
    router.include_router(players.router, prefix="/players", tags=["players"])
except Exception:
    pass
