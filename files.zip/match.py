"""
Match — modelo Pydantic del backend.
Contrato entre scraping_bridge y los endpoints de la API.
"""
from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel

ArgRelevance = Literal["seleccion", "club_arg", "jugador_arg", "none"]
MatchStatus  = Literal["live", "upcoming", "finished"]


class Match(BaseModel):
    id: str
    sport: str
    competition: str = ""

    home_team: str = ""
    away_team: str = ""

    home_score: Optional[int] = None
    away_score: Optional[int] = None

    status: MatchStatus = "upcoming"
    minute: Optional[str] = None

    datetime: Optional[str] = None        # ISO UTC
    start_time: Optional[str] = None      # hora local Argentina "21:30"

    argentina_relevance: ArgRelevance = "none"
    argentina_team: Optional[str] = None

    broadcast: Optional[str] = None

    class Config:
        # Permite recibir tanto dicts como objetos con atributos
        from_attributes = True
